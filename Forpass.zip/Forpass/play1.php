<!DOCTYPE html>
<html>
    <title>
    </title>
        <link rel="stylesheet" type="text/css" href="style4.css">
        
        <head>
            <body>
                <header>
                    <div class="logo"><h1>PLAYGROUND</h1></div>
                    <nav>    
                        <div class="MENU">
                            <a href="#">Playground - 1</a>
                            <a href="#">Playground - 2</a>
                            <a href="#">Playground - 3</a>
                            <a href="#">Playground - 4</a>
                                                        
                        </div>
                    </nav>
                <main>
                    <h1>WELCOME TO A BLOCK</h1>
                    </main>
                </header>
            </body>
        </head>
    </html>