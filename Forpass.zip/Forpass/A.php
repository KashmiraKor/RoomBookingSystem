<!DOCTYPE html>
<html>
    <title>
    </title>
        <link rel="stylesheet" type="text/css" href="style4.css">
        
        <head>
            <body>
                <header>
                    <div class="logo"><h1>CLASSROOMS</h1></div>
                    <nav>    
                        <div class="MENU">
                            <a href="#">101</a>
                            <a href="#">102</a>
                            <a href="#">103</a>
                            <a href="#">104</a>
                            <a href="#">105</a>
                            
                        </div>
                    </nav>
                <main>
                    <h1>WELCOME TO A BLOCK</h1>
                    </main>
                </header>
            </body>
        </head>
    </html>