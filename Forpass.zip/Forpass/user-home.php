
<!DOCTYPE html>
<html>
    <title>

    </title>
    <link rel="stylesheet" type="text/css" href="style3.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Texturina&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&display=swap" rel="stylesheet">

    
    <head>
        <body>
<header>
    <div class="logo"><h1>USER PROFILE</h1></div>
    <nav>
        <img src="https://img.icons8.com/office/80/000000/person-male.png"> 

        
        
<div class="MENU">
    <div class="dropdown">
        <span>LECTURE</span>
        <div class="dropdown-content">
            
            <p> <a href="A.php">A Block</a></p>
            <p> <a href="B.php">B Block</a></p>
            <p>C Block</p>
            <p>D Block</p>
            <p>E Block</p>
            <p>F Block</p>
            <p>M Block</p>

        </div>
        </div>
        <div class="dropdown">
        <span>PLAYGROUND</span>
        <div class="dropdown-content">
            <p><a href=""> 1st Playground</a> </p>
            <p> 2nd Playground</p>
            <p> 3rd Playground</p>
            <p> 4th Playground</p>
            
        </div>
        </div>
        <a href="#">HALLS</a>

        <div class="dropdown">
            <span>CONTACT US</span>
            <div class="dropdown-content">
                <p>occupie04@gmail.com</p>
        </div>
</div>
        <a href="login-user.php">LOGOUT</a>
    
    </div>
    </nav>
<main>
    <h1> WELCOME  TO  OCCUPIE</h1>
        <span></span>
</main>
        
    
</header>
        </body>    
    </head>
</html>